package com.adbroadcaster;

import android.content.Context;
import android.content.SharedPreferences;

public class AdPrefs {
    private static final String PREF = "ad_prefs";

    public static void save(Context ctx, String title, String message, String link) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("title", title)
            .putString("message", message)
            .putString("link", link)
            .apply();
    }

    public static String getTitle(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("title", "");
    }

    public static String getMessage(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("message", "");
    }

    public static String getLink(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("link", "");
    }
}
