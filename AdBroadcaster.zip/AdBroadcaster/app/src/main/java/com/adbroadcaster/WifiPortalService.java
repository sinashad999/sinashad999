package com.adbroadcaster;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import java.io.*;
import java.net.*;

public class WifiPortalService extends Service {

    private static final String TAG = "WifiPortal";
    private static final String CHANNEL_ID = "wifi_channel";
    private static final int PORT = 8080;
    private ServerSocket serverSocket;
    private Thread serverThread;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(2, buildNotification("Wi-Fi Portal: در حال راه‌اندازی..."));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startHttpServer();
        return START_STICKY;
    }

    private void startHttpServer() {
        serverThread = new Thread(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                Log.i(TAG, "HTTP server started on port " + PORT);
                updateNotification("Wi-Fi Portal: ✓ فعال - پورت " + PORT);

                while (!serverSocket.isClosed()) {
                    try {
                        Socket client = serverSocket.accept();
                        new Thread(() -> handleClient(client)).start();
                    } catch (IOException e) {
                        if (!serverSocket.isClosed()) Log.e(TAG, "Accept error", e);
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "Server error", e);
                updateNotification("Wi-Fi Portal: خطا - " + e.getMessage());
            }
        });
        serverThread.setDaemon(true);
        serverThread.start();
    }

    private void handleClient(Socket client) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            OutputStream out = client.getOutputStream();

            // Read HTTP request
            String requestLine = in.readLine();
            if (requestLine == null) { client.close(); return; }
            Log.d(TAG, "Request: " + requestLine);

            // Read headers
            String line;
            while ((line = in.readLine()) != null && !line.isEmpty()) { /* skip */ }

            // Build HTML response
            String html = buildAdHtml();
            String response = "HTTP/1.1 200 OK\r\n"
                + "Content-Type: text/html; charset=UTF-8\r\n"
                + "Content-Length: " + html.getBytes("UTF-8").length + "\r\n"
                + "Connection: close\r\n"
                + "\r\n"
                + html;

            out.write(response.getBytes("UTF-8"));
            out.flush();
            client.close();
        } catch (IOException e) {
            Log.e(TAG, "Client error", e);
        }
    }

    private String buildAdHtml() {
        String title   = AdPrefs.getTitle(this);
        String message = AdPrefs.getMessage(this);
        String link    = AdPrefs.getLink(this);

        String linkHtml = "";
        if (!link.isEmpty()) {
            linkHtml = "<a href='" + link + "' class='btn'>بیشتر بدانید ←</a>";
        }

        return "<!DOCTYPE html><html dir='rtl' lang='fa'><head>"
            + "<meta charset='UTF-8'>"
            + "<meta name='viewport' content='width=device-width, initial-scale=1'>"
            + "<title>" + title + "</title>"
            + "<style>"
            + "body{font-family:Tahoma,Arial;background:#f0f4ff;margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;}"
            + ".card{background:#fff;border-radius:16px;padding:32px;max-width:400px;width:90%;box-shadow:0 8px 32px #0002;text-align:center;}"
            + "h1{color:#1a237e;font-size:1.6em;margin-bottom:12px;}"
            + "p{color:#444;font-size:1.1em;line-height:1.7;}"
            + ".btn{display:inline-block;margin-top:20px;padding:12px 28px;background:#1976D2;color:#fff;border-radius:8px;text-decoration:none;font-size:1em;}"
            + ".logo{font-size:2.5em;margin-bottom:8px;}"
            + "</style></head><body>"
            + "<div class='card'>"
            + "<div class='logo'>📢</div>"
            + "<h1>" + title + "</h1>"
            + "<p>" + message + "</p>"
            + linkHtml
            + "</div></body></html>";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (serverSocket != null && !serverSocket.isClosed())
                serverSocket.close();
        } catch (IOException e) { Log.e(TAG, "Close error", e); }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void createNotificationChannel() {
        NotificationChannel ch = new NotificationChannel(
            CHANNEL_ID, "Wi-Fi Portal", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🌐 AdBroadcaster")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build();
    }

    private void updateNotification(String text) {
        getSystemService(NotificationManager.class).notify(2, buildNotification(text));
    }
}
