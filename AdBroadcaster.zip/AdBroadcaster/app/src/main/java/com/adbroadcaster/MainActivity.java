package com.adbroadcaster;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int PERM_REQUEST = 100;

    Switch switchBle, switchWifi;
    EditText etTitle, etMessage, etLink;
    Button btnSave, btnStartStop;
    TextView tvStatus;
    boolean isRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchBle   = findViewById(R.id.switchBle);
        switchWifi  = findViewById(R.id.switchWifi);
        etTitle     = findViewById(R.id.etTitle);
        etMessage   = findViewById(R.id.etMessage);
        etLink      = findViewById(R.id.etLink);
        btnSave     = findViewById(R.id.btnSave);
        btnStartStop= findViewById(R.id.btnStartStop);
        tvStatus    = findViewById(R.id.tvStatus);

        btnSave.setOnClickListener(v -> saveAd());
        btnStartStop.setOnClickListener(v -> toggleBroadcast());

        requestPermissions();
    }

    void saveAd() {
        String title   = etTitle.getText().toString().trim();
        String message = etMessage.getText().toString().trim();
        String link    = etLink.getText().toString().trim();

        if (title.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "عنوان و پیام را وارد کنید", Toast.LENGTH_SHORT).show();
            return;
        }

        AdPrefs.save(this, title, message, link);
        Toast.makeText(this, "تبلیغ ذخیره شد ✓", Toast.LENGTH_SHORT).show();
    }

    void toggleBroadcast() {
        if (!isRunning) {
            if (switchBle.isChecked()) startBle();
            if (switchWifi.isChecked()) startWifi();
            isRunning = true;
            btnStartStop.setText("⏹ توقف پخش");
            tvStatus.setText("● در حال پخش...");
            tvStatus.setTextColor(0xFF4CAF50);
        } else {
            if (switchBle.isChecked()) stopBle();
            if (switchWifi.isChecked()) stopWifi();
            isRunning = false;
            btnStartStop.setText("▶ شروع پخش");
            tvStatus.setText("○ متوقف");
            tvStatus.setTextColor(0xFF9E9E9E);
        }
    }

    void startBle() {
        Intent i = new Intent(this, BleAdvertiserService.class);
        startForegroundService(i);
    }

    void stopBle() {
        stopService(new Intent(this, BleAdvertiserService.class));
    }

    void startWifi() {
        Intent i = new Intent(this, WifiPortalService.class);
        startForegroundService(i);
    }

    void stopWifi() {
        stopService(new Intent(this, WifiPortalService.class));
    }

    void requestPermissions() {
        List<String> perms = new ArrayList<>();
        String[] required = {
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.INTERNET,
            Manifest.permission.FOREGROUND_SERVICE,
        };
        for (String p : required) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                perms.add(p);
        }
        if (!perms.isEmpty())
            ActivityCompat.requestPermissions(this, perms.toArray(new String[0]), PERM_REQUEST);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Load saved ad
        etTitle.setText(AdPrefs.getTitle(this));
        etMessage.setText(AdPrefs.getMessage(this));
        etLink.setText(AdPrefs.getLink(this));
    }
}
