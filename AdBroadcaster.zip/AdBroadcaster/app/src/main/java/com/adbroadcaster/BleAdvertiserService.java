package com.adbroadcaster;

import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.*;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import java.nio.charset.StandardCharsets;

public class BleAdvertiserService extends Service {

    private static final String TAG = "BleAdvertiser";
    private static final String CHANNEL_ID = "ble_channel";
    private BluetoothLeAdvertiser advertiser;
    private AdvertiseCallback advertiseCallback;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification("BLE: در حال راه‌اندازی..."));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startAdvertising();
        return START_STICKY;
    }

    private void startAdvertising() {
        BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        if (bm == null) return;
        BluetoothAdapter adapter = bm.getAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            Log.w(TAG, "Bluetooth not available");
            return;
        }
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Log.w(TAG, "BLE not supported");
            return;
        }

        advertiser = adapter.getBluetoothLeAdvertiser();
        if (advertiser == null) {
            Log.w(TAG, "BLE advertising not supported");
            return;
        }

        String title   = AdPrefs.getTitle(this);
        String message = AdPrefs.getMessage(this);
        String link    = AdPrefs.getLink(this);
        // Combine into short payload (max 26 bytes for manufacturer data)
        String payload = (title + ": " + message).substring(0, Math.min(title.length() + message.length() + 2, 20));

        AdvertiseSettings settings = new AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(false)
            .build();

        byte[] payloadBytes = payload.getBytes(StandardCharsets.UTF_8);
        // Limit to 20 bytes
        if (payloadBytes.length > 20) {
            byte[] trimmed = new byte[20];
            System.arraycopy(payloadBytes, 0, trimmed, 0, 20);
            payloadBytes = trimmed;
        }

        AdvertiseData data = new AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addManufacturerData(0x004C, payloadBytes) // Apple-like company ID for visibility
            .build();

        advertiseCallback = new AdvertiseCallback() {
            @Override
            public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                Log.i(TAG, "BLE advertising started");
                updateNotification("BLE: ✓ در حال پخش - " + title);
            }
            @Override
            public void onStartFailure(int errorCode) {
                Log.e(TAG, "BLE advertising failed: " + errorCode);
                updateNotification("BLE: خطا در راه‌اندازی (" + errorCode + ")");
            }
        };

        if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED) {
            advertiser.startAdvertising(settings, data, advertiseCallback);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (advertiser != null && advertiseCallback != null) {
            if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED) {
                advertiser.stopAdvertising(advertiseCallback);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void createNotificationChannel() {
        NotificationChannel ch = new NotificationChannel(
            CHANNEL_ID, "BLE Advertiser", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("📡 AdBroadcaster")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build();
    }

    private void updateNotification(String text) {
        getSystemService(NotificationManager.class).notify(1, buildNotification(text));
    }
}
