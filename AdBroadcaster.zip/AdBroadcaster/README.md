# 📡 AdBroadcaster - راهنمای نصب

## معرفی
اپ اندروید برای پخش تبلیغات از طریق **بلوتوث BLE** و **Wi-Fi Captive Portal** بدون نیاز به اپ در گیرنده.

---

## ساختار پروژه
```
AdBroadcaster/
├── app/src/main/
│   ├── java/com/adbroadcaster/
│   │   ├── MainActivity.java         ← رابط کاربری اصلی
│   │   ├── BleAdvertiserService.java ← سرویس پخش بلوتوث
│   │   ├── WifiPortalService.java    ← سرور HTTP برای Wi-Fi
│   │   └── AdPrefs.java             ← ذخیره تنظیمات
│   ├── res/layout/activity_main.xml  ← طراحی UI فارسی
│   └── AndroidManifest.xml
├── build.gradle
└── settings.gradle
```

---

## مراحل نصب در Android Studio

1. **Android Studio** را باز کنید
2. منوی **File > Open** → پوشه `AdBroadcaster` را انتخاب کنید
3. صبر کنید تا Gradle sync انجام شود
4. گوشی اندروید را وصل کنید (Developer Mode فعال باشد)
5. دکمه **Run ▶** را بزنید

### نیازمندی‌ها
- Android Studio Hedgehog یا جدیدتر
- Android SDK 26+ (Android 8.0)
- گوشی با پشتیبانی BLE Advertising

---

## نحوه استفاده

### پخش بلوتوث BLE
- گوشی‌های اطراف که **BLE Scanner** دارند پیام را می‌بینند
- برخی گوشی‌ها نوتیفیکیشن نشان می‌دهند (بستگی به تنظیمات دستگاه)
- برد تقریبی: **۱۰ تا ۱۰۰ متر**

### پخش Wi-Fi Portal
- سرور HTTP روی **پورت ۸۰۸۰** راه‌اندازی می‌شود
- IP گوشی خود را پیدا کنید: تنظیمات > وای‌فای > اطلاعات اتصال
- آدرس `http://[IP گوشی]:8080` را در مرورگر باز کنید
- صفحه تبلیغ زیبا با فارسی نمایش داده می‌شود

**برای پیدا کردن IP:**
```
تنظیمات > Wi-Fi > نام شبکه > جزئیات > آدرس IP
```
یا از Logcat در Android Studio (تگ: WifiPortal)

---

## نکات مهم
- برای BLE Advertising گوشی باید **Android 8+** داشته باشد
- مجوزهای درخواستی را تأیید کنید
- برای Wi-Fi Portal بهتر است گوشی و گیرنده‌ها روی یک شبکه باشند
- پورت ۸۰۸۰ را در فایروال باز کنید اگر نیاز بود

---

## توسعه بیشتر
- اضافه کردن تصویر به تبلیغ
- پشتیبانی از چند تبلیغ با زمان‌بندی
- آمار بازدید
- کیو‌آر کد برای لینک
